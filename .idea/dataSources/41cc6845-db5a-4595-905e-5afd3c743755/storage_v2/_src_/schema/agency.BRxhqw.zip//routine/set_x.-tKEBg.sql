create
    definer = root@localhost procedure set_x(OUT value int)
BEGIN
    SET @x = value;
    SET value = 1000;
END;

