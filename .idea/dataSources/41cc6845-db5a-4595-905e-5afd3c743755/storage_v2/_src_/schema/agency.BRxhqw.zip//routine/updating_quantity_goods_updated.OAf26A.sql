create
    definer = root@localhost procedure updating_quantity_goods_updated(IN Id_product int, IN count_product int)
BEGIN
    SELECT order_database.products.quantity into @quantity_before_renewal
    FROM order_database.products WHERE order_database.products.Id = Id_product;
    UPDATE  order_database.products  SET order_database.products.quantity = @quantity_before_renewal - count_product
    WHERE  order_database.products.Id=Id_product;

END;

