create
    definer = root@localhost procedure creating_new_record_in_orders_table(OUT Id_order int, IN password varchar(50))
BEGIN
INSERT INTO order_database.orders(id, id_client, order_data, sum_order)
VALUE (NULL, (SELECT order_database.clients.Id FROM order_database.clients WHERE order_database.clients.password=password),
NOW(),NULL);
 set Id_order =(SELECT order_database.orders.Id FROM order_database.orders WHERE sum_order=NULL AND  order_database.orders.Id!=NULL);

END;

