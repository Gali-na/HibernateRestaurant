create
    definer = root@localhost procedure retutn_price_product(IN Id_product int, OUT price_product int)
BEGIN

    set Id_product =(SELECT order_database.products.price FROM order_database.products WHERE order_database.products.Id=Id_product);

END;

