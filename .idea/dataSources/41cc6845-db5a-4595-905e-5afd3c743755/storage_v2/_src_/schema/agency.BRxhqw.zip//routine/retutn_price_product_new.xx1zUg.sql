create
    definer = root@localhost procedure retutn_price_product_new(IN Id_product int, OUT price_product int)
BEGIN

     SELECT order_database.products.price INTO price_product FROM order_database.products WHERE order_database.products.Id=Id_product;

END;

