create
    definer = root@localhost procedure checking_number_goods_warehouse(IN Id_product int, IN count_product int, OUT rezult int)
BEGIN

    SELECT order_database.products.quantity-count_product INTO rezult FROM order_database.products WHERE order_database.products.Id=Id_product;

END;

