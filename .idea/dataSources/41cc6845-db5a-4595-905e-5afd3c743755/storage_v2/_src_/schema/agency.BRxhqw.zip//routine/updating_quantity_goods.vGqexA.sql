create
    definer = root@localhost procedure updating_quantity_goods(IN Id_product int, IN count_product int)
BEGIN
    UPDATE  order_database.products  SET order_database.products.quantity = (SELECT order_database.products.quantity
    FROM order_database.products WHERE order_database.products.Id = Id_product) - count_product
    WHERE  order_database.products.Id=Id_product;

END;

