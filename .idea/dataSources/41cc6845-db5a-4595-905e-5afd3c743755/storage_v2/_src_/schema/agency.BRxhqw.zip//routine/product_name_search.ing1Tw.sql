create
    definer = root@localhost procedure product_name_search(IN Id_product int, OUT name_product varchar(50))
BEGIN

    SELECT order_database.products.name INTO name_product FROM order_database.products WHERE order_database.products.Id=Id_product;

END;

